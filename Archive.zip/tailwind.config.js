/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{html,js,ts,svelte}"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
